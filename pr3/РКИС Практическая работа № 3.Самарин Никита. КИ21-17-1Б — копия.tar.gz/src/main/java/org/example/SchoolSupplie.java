package org.example;

/**
 * Интерфейс школьной принадлежности
 */
public interface SchoolSupplie {
  public String getDescription();
}
