package pr7_client;

import java.net.URISyntaxException;

public class BagException extends Exception {
  public BagException(String unable_to_update_bag, URISyntaxException e) {

  }
}
