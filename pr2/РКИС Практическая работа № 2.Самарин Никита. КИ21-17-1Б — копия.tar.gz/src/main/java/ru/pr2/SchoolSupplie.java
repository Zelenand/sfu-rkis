package ru.pr2;

/**
 * Интерфейс школьной принадлежности
 */
public interface SchoolSupplie {
  public String getDescription();
}
